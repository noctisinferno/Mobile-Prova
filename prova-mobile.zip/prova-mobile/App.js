import React, { useState } from 'react';
import { View, Text, Button, TextInput, StyleSheet } from 'react-native';

export default function App() {
  const [currentPage, setCurrentPage] = useState('Login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [authenticated, setAuthenticated] = useState(false);
  const [registeredUsers, setRegisteredUsers] = useState([]);

  const employees = [
    { username: 'funcionario1', password: 'senha1' },
    { username: 'funcionario2', password: 'senha2' },
  ];

  const handleLogin = () => {
    const employee = employees.find(
      (emp) => emp.username === username && emp.password === password
    );

    const user = registeredUsers.find(
      (usr) => usr.username === username && usr.password === password
    );

    if (employee || user) {
      setAuthenticated(true);
      setCurrentPage('Home');
    } else {
      setAuthenticated(false);
      alert('Nome de usuário ou senha incorretos');
    }
  };

  const handleRegistro = () => {
    if (!username || !password) {
      alert('Por favor, preencha todos os campos');
      return;
    }

    if (registeredUsers.find((user) => user.username === username)) {
      alert('Este nome de usuário já está em uso');
      return;
    }

    setRegisteredUsers([...registeredUsers, { username, password }]);
    setUsername('');
    setPassword('');
    alert('Registro bem-sucedido! Você pode fazer login agora.');
    setCurrentPage('Login');
  };

  const renderPage = () => {
    if (currentPage === 'Home') {
      return (
        <View style={styles.homeContainer}>
          <Text style={styles.homeMessage}>Bem-vindo!!</Text>
          <Button title="Sair" onPress={() => setCurrentPage('Login')} />
        </View>
      );
    } else {
      return (
        <View style={styles.container}>
          <Text style={styles.title}>Tela de {currentPage}</Text>
          <TextInput
            style={styles.input}
            placeholder="Nome de Usuário"
            onChangeText={(text) => setUsername(text)}
            value={username}
          />
          <TextInput
            style={styles.input}
            placeholder="Senha"
            onChangeText={(text) => setPassword(text)}
            value={password}
            secureTextEntry={true}
          />
          <Button title="Login" onPress={currentPage === 'Login' ? handleLogin : handleRegistro} />
          {currentPage === 'Login' && (
            <Button title="Registrar" onPress={() => setCurrentPage('Registro')} />
          )}
        </View>
      );
    }
  };

  return (
    <View style={styles.background}>
      {authenticated ? renderPage() : renderPage('Login')}
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: '#e0e0e0', 
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    width: '80%',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  homeContainer: {
    flex: 1,
    backgroundColor: 'gray', 
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderColor: 'gray',
    marginBottom: 10,
    paddingLeft: 10,
  },
  homeMessage: {
    fontSize: 24,
    fontWeight: 'bold', 
    color: 'white',
  },
});
